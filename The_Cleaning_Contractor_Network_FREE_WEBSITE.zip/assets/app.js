
document.getElementById("year").textContent=new Date().getFullYear();
function __toggleNav(){document.querySelector(".nav")?.classList.toggle("show");}
